Several useful example scripts are available at

  http://code.google.com/p/pyspeech/wiki/Examples

and an example script to get you started is in example.py.  To run it, type

  python.exe example.py

in your Python directory.

Questions?  Visit our project page at http://pyspeech.googlecode.com .

Thanks.
Michael Gundlach
gundlach@gmail.com


# ASR demo 2

对sdk做出封装示例

测试成功后，可以修改 yours_main.cpp 内static void set_config(bds::BDSSDKMessage &cfg_params)内的设置参数

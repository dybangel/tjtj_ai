# ASR demo



简单地并发测试sdk，测试pcm目录下的音频， 原始音频目前仅支持16k采样率



测试成功后，可以修改 asr_set_config_params内的设置参数